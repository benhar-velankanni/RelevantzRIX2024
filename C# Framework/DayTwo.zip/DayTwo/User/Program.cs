﻿class User
{
    public string Name;
    public string PreferredTheme;
 
    public User(string name, string preferredTheme)
    {
        PreferredTheme = string.IsNullOrWhiteSpace(preferredTheme) ? "Light" : preferredTheme;
        Name = name;
    }
 
    public void DisplayPreferences()
    {
        Console.WriteLine($"{Name}'s preferred theme: {PreferredTheme}");
    }
}
 
class Program
{
    static void Main()
    {
        Console.Write("Enter number of users: ");
        int n = Convert.ToInt32(Console.ReadLine());
 
        for (int i = 0; i < n; i++)
        {
            Console.Write($"Enter user {i + 1} name: ");
            string name = Console.ReadLine();
 
            Console.Write($"Enter preferred theme for {name} : ");
            string theme = Console.ReadLine();
 
            User user = new User(name, theme);
            user.DisplayPreferences();
        }
    }
}