﻿class Book{
    public string Title {get; set; }
    public string Author {get; set; }
    public bool IsAvailable {get; set; }
 
    public Book(string title, string author, bool isAvailable){
        this.Title = title;
        this.Author = author;
        this.IsAvailable = isAvailable;
    }
}
class Member{
    public int MemberId {get; set; }
    public string Name {get; set; }
    public List<Book> BorrowedBooks {get; set; }
 
    public Member(int memberId, string name){
        this.MemberId = memberId;
        this.Name = name;
        this.BorrowedBooks = new List<Book>();
    }
 
    public void BorrowBook(Book book){
        if(book.IsAvailable){
            BorrowedBooks.Add(book);
            book.IsAvailable = false;
            Console.WriteLine("Book borrowed successfully.");
        }else{
            Console.WriteLine("Book is not available.");
        }
    }
 
    public void ReturnBook(Book book){
        if(BorrowedBooks.Contains(book)){
            BorrowedBooks.Remove(book);
            book.IsAvailable = true;
            Console.WriteLine("Book returned successfully.");
        }else{
            Console.WriteLine("Book is not borrowed.");
        }
    }
 
}
class Library{
    public List<Book> Books {get; set;} = new List<Book>();
 
    public void AddBook(Book book){
        Books.Add(book);
        Console.WriteLine("Book added successfully.");
    }
    public void ShowAvailableBooks(){
        Console.WriteLine("\nAvailable Books:");
        foreach(var book in Books){
            if(book.IsAvailable){
                Console.WriteLine($"- {book.Title} by {book.Author}");
            }
        }
    }
}
 
class Program{
    static void Main(){
        Library library = new Library();
        Console.WriteLine("Enter number of books to add:");
        int n = Convert.ToInt32(Console.ReadLine());
        for(int i=0;i<n;i++){
            Console.WriteLine("Enter book title:");
            string title = Console.ReadLine();
            Console.WriteLine("Enter book author:");
            string author = Console.ReadLine();
            Book book = new Book(title, author, true);
            library.AddBook(book);
        }
        library.ShowAvailableBooks();
        Console.WriteLine("Enter member ID:");
        int memberId = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Enter member name:");
        string name = Console.ReadLine();
        Member member = new Member(memberId, name);
        Console.WriteLine("Enter number of books to borrow:");
        n = Convert.ToInt32(Console.ReadLine());
        for(int i=0;i<n;i++){
            Console.WriteLine("Enter book title:");
            string title = Console.ReadLine();
            Book book = library.Books.Find(b => b.Title == title);
            if(book != null){
                member.BorrowBook(book);
            }else{
                Console.WriteLine("Book not found.");
            }
        }
        Console.WriteLine("Enter number of books to return:");
        n = Convert.ToInt32(Console.ReadLine());
        for(int i=0;i<n;i++){
            Console.WriteLine("Enter book title:");
            string title = Console.ReadLine();
            Book book = library.Books.Find(b => b.Title == title);
            if(book != null){
                member.ReturnBook(book);
            }else{
                Console.WriteLine("Book not found.");
            }
        }
    }
}
 