﻿class Anagram
{
    public bool IsAnagram(string s1, string s2)
    {
        var s1Array = s1.ToLower().ToCharArray();
        var s2Array = s2.ToLower().ToCharArray();

        Array.Sort(s1Array);
        Array.Sort(s2Array);

        return s1Array.SequenceEqual(s2Array);
    }
}

class Program
{
    public static void Main()
    {
        var anagram = new Anagram();

        Console.Write("Enter the first string: ");
        var s1 = Console.ReadLine();

        Console.Write("Enter the second string: ");
        var s2 = Console.ReadLine();

        if (anagram.IsAnagram(s1, s2))
            Console.WriteLine("The strings are anagrams.");
        else
            Console.WriteLine("The strings are not anagrams.");
    }
}

