﻿using System;

public class Employee
{
    public string Name { get; set; }
    public int BaseSalary { get; set; }

    public Employee(string name, int baseSalary)
    {
        Name = name;
        BaseSalary = baseSalary;
    }

    public virtual int CalculateSalary()
    {
        return BaseSalary;
    }
}

public class Manager : Employee
{
    public int Bonus { get; set; }

    public Manager(string name, int baseSalary, int bonus)
        : base(name, baseSalary)
    {
        Bonus = bonus;
    }

    public override int CalculateSalary()
    {
        return BaseSalary + Bonus;
    }
}

public class Developer : Employee
{
    public int OvertimeHours { get; set; }
    public int OvertimeRate { get; set; }

    public Developer(string name, int baseSalary, int overtimeHours, int overtimeRate)
        : base(name, baseSalary)
    {
        OvertimeHours = overtimeHours;
        OvertimeRate = overtimeRate;
    }

    public override int CalculateSalary()
    {
        return BaseSalary + (OvertimeHours * OvertimeRate);
    }
}

class Program
{
    static void Main()
    {
        Console.Write("Enter manager's name: ");
        string managerName = Console.ReadLine();
        Console.Write("Enter manager's base salary: ");
        int managerBaseSalary = Convert.ToInt32(Console.ReadLine());
        Console.Write("Enter manager's bonus: ");
        int managerBonus = Convert.ToInt32(Console.ReadLine());

        Console.Write("Enter developer's name: ");
        string developerName = Console.ReadLine();
        Console.Write("Enter developer's base salary: ");
        int developerBaseSalary = Convert.ToInt32(Console.ReadLine());
        Console.Write("Enter developer's overtime hours: ");
        int developerOvertimeHours = Convert.ToInt32(Console.ReadLine());
        Console.Write("Enter developer's overtime rate: ");
        int developerOvertimeRate = Convert.ToInt32(Console.ReadLine());

        Employee manager = new Manager(managerName, managerBaseSalary, managerBonus);
        Employee developer = new Developer(developerName, developerBaseSalary, developerOvertimeHours, developerOvertimeRate);

        Console.WriteLine($"{manager.Name}'s Salary: {manager.CalculateSalary()}");
        Console.WriteLine($"{developer.Name}'s Salary: {developer.CalculateSalary()}");
    }
}

