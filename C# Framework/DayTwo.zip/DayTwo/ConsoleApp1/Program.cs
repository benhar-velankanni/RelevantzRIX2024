﻿class Encap{
    private long itemId;
    private string itemName;
    private decimal itemPrice;

    public long ItemId{
        get{
            return itemId;
        }
        set{
            if(value > 0){
                itemId = value;
            }
            else{
                Console.WriteLine("Item Id must be greater than 0");
                itemId = 0;
            }
        }
    }
    public decimal ItemPrice{
        get{
            return itemPrice;
        }
        set{
            if(value > 0){
                itemPrice = value;
            }
            else{
                Console.WriteLine("Item Price must be greater than 0");
                itemPrice = 0.00M;
            }
        }
    }
}
class Program{
    public static void Main(){
        Encap e = new Encap();
        Console.Write("Enter Item Id: ");
        e.ItemId = Convert.ToInt64(Console.ReadLine());
        Console.Write("Enter Item Price: ");
        e.ItemPrice = Convert.ToDecimal(Console.ReadLine());
        Console.WriteLine($"Item Id: {e.ItemId} Item Price: {e.ItemPrice:F2}");
    }
}
