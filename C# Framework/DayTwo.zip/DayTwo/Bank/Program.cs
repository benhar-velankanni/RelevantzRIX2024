﻿class BankAccount{
    private int accountNumber;
    private decimal balance;

    public int AccountNumber{
        get{
            return accountNumber;
        }
        set{
            if(value > 0){
                accountNumber = value;
            }
            else{
                Console.WriteLine("Account Number must be greater than 0");
            }
        }
    }

    public decimal Balance{
        get{
            return balance;
        }
        set{
            if(value >= 0){
                balance = value;
            }
            else{
                Console.WriteLine("Balance cannot be negative");
            }
        }
    }

    public void Deposit(decimal amount){
        if(amount > 0){
            Balance += amount;
        }
        else{
            Console.WriteLine("Deposit amount must be greater than 0");
        }
    }

    public void Withdraw(decimal amount){
        if(amount > 0 && Balance >= amount){
            Balance -= amount;
        }
        else if(amount <= 0){
            Console.WriteLine("Withdraw amount must be greater than 0");
        }
        else{
            Console.WriteLine("Insufficient balance");
        }
    }


}

class Program{
    static void Main(string[] args){
        BankAccount account = new BankAccount();
        
        Console.Write("Enter Account Number: ");
        account.AccountNumber = Convert.ToInt32(Console.ReadLine());

        Console.Write("Enter Initial Balance: ");
        account.Balance = Convert.ToDecimal(Console.ReadLine());

        Console.WriteLine();
        Console.WriteLine("Account Details");
        Console.WriteLine("Account Number: " + account.AccountNumber);
        Console.WriteLine("Balance: " + account.Balance);

        Console.WriteLine();
        Console.Write("Enter Deposit Amount: ");
        decimal depositAmount = Convert.ToDecimal(Console.ReadLine());
        account.Deposit(depositAmount);
        Console.WriteLine("After Deposit: " + account.Balance);

        Console.WriteLine();
        Console.Write("Enter Withdraw Amount: ");
        decimal withdrawAmount = Convert.ToDecimal(Console.ReadLine());
        account.Withdraw(withdrawAmount);
        Console.WriteLine("After Withdraw: " + account.Balance);
    }
}

