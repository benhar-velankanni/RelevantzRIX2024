﻿class Swap
{
    public void SwapNumbers(ref int x, ref int y)
    {
        int temp = x;
        x = y;
        y = temp;
    }
}

class Program
{
    public static void Main()
    {
        Console.WriteLine("Enter the first number: ");
        int a = Convert.ToInt32(Console.ReadLine());

        Console.WriteLine("Enter the second number: ");
        int b = Convert.ToInt32(Console.ReadLine());

        Console.WriteLine("Before swap: a = {0}, b = {1}", a, b);

        Swap swapInstance = new Swap();
        swapInstance.SwapNumbers(ref a, ref b);

        Console.WriteLine("After swap: a = {0}, b = {1}", a, b);
    }
}

