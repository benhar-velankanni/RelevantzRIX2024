﻿namespace Shape
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the radius:");
            int rad=Convert.ToInt32(Console.ReadLine());
            Circle c = new Circle(rad);
            Console.WriteLine($"Circle Area: {c.GetArea():F2}");

            Console.WriteLine();
            Console.WriteLine("Enter length and breadth:");
            int l=Convert.ToInt32(Console.ReadLine());
            int b=Convert.ToInt32(Console.ReadLine());
            Rectangle r = new Rectangle(l,b);
            Console.WriteLine($"Rectangle Area: {r.GetArea():F2}");

            Console.WriteLine();
            Console.WriteLine("Enter threesides:");
            int a = Convert.ToInt32(Console.ReadLine());
            int b1 = Convert.ToInt32(Console.ReadLine());
            int c1 = Convert.ToInt32(Console.ReadLine());
            Triangle t = new Triangle(a,b1,c1);
            Console.WriteLine($"Triangle Area: {t.GetArea():F2}");
        }
    }

    abstract class Shape
    {
        public abstract double GetArea();
    }

    class Circle : Shape
    {
        private double radius;

        public Circle(double radius)
        {
            this.radius = radius;
        }

        public override double GetArea()
        {
            return Math.PI * radius * radius;
        }
    }

    class Rectangle : Shape
    {
        private double width;
        private double height;

        public Rectangle(double width, double height)
        {
            this.width = width;
            this.height = height;
        }

        public override double GetArea()
        {
            return width * height;
        }
    }

    class Triangle : Shape
    {
        private double a;
        private double b;
        private double c;

        public Triangle(double a, double b, double c)
        {
            this.a = a;
            this.b = b;
            this.c = c;
        }

        public override double GetArea()
        {
            double s = (a + b + c) / 2;
            return Math.Sqrt(s * (s - a) * (s - b) * (s - c));
        }
    }
}

