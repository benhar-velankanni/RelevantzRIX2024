﻿class Employee
{
    public string Name;
    public int? Bonus;
 
    public Employee(string name, int? bonus)
    {
       this.Name = name;
       this.Bonus = bonus;
    }
 
    public void DisplayBonus()
    {
        if (Bonus.HasValue)
        {
            Console.WriteLine($"{Name}'s bonus: {Bonus.Value}");
        }
        else
        {
            Console.WriteLine($"{Name} is not eligible for a bonus.");
        }
    }
}
 
class Program
{
    static void Main()
    {
        Console.Write("Enter number of employees: ");
       
       
        int count = int.Parse(Console.ReadLine());
        for (int i = 0; i < count; i++)
        {
            Console.Write("Enter employee name: ");
            string name = Console.ReadLine();
 
            Console.Write("Enter bonus amount ");
            int? bonus = int.TryParse(Console.ReadLine(), out int value) ? value : (int?)null;
 
            Employee employee = new Employee(name, bonus);
            employee.DisplayBonus();
        }
    }
}