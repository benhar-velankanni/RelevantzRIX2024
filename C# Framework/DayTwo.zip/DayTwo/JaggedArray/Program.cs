﻿class Program
{
    public static void Main()
    {
        Console.Write("Enter the number of students: ");
        int studentCount = Convert.ToInt32(Console.ReadLine());

        int[][] studentMarks = new int[studentCount][];

        for (int i = 0; i < studentCount; i++)
        {
            Console.Write($"Enter the number of marks for student {i + 1}: ");
            int marksCount = Convert.ToInt32(Console.ReadLine());

            studentMarks[i] = new int[marksCount];

            for (int j = 0; j < marksCount; j++)
            {
                Console.Write($"Enter mark {j + 1} for student {i + 1}: ");
                studentMarks[i][j] = Convert.ToInt32(Console.ReadLine());
            }
        }

        for (int i = 0; i < studentCount; i++)
        {
            Console.Write($"Marks for student {i + 1}: ");
            for (int j = 0; j < studentMarks[i].Length; j++)
            {
                Console.Write($"{studentMarks[i][j]} ");
            }
            Console.WriteLine();

            int totalMarks = 0;
            for (int j = 0; j < studentMarks[i].Length; j++)
            {
                totalMarks += studentMarks[i][j];
            }
            double average = (double)totalMarks / studentMarks[i].Length;
            Console.WriteLine($"Average marks for student {i + 1}: {average:F2}");
        }
    }
}

