﻿namespace Status
{
    class Program
    {
        public enum Statustype
        {
            Pending = 1,
            Shipped = 2,
            Delivered = 3,
            Cancelled = 4
        }

        static void Main(string[] args)
        {
            Console.Write("Enter order code (1-4)): ");
            string input = Console.ReadLine();//1

            if (Enum.TryParse(input, true, out Statustype status))
            {
                switch (status)
                {
                    case Statustype.Pending:
                        Console.WriteLine("Order is pending");
                        break;
                    case Statustype.Shipped:
                        Console.WriteLine("Order is shipped");
                        break;
                    case Statustype.Delivered:
                        Console.WriteLine("Order is delivered");
                        break;
                    case Statustype.Cancelled:
                        Console.WriteLine("Order is cancelled");
                        break;
                    default:
                        Console.WriteLine("Invalid status internal error");
                        break;
                }
            }
        }
    }
}

