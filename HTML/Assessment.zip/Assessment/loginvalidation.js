function validation(){
    var username = document.getElementById("username").value;
    if(username == ""){
        alert("Please enter your username");
        return false;
    }
    var password = document.getElementById("password").value;
    if(password == ""){
        alert("Please enter your password");
        return false;
    }
}
// use cookies to handle login page
 username.setcookie("username", username, 30);
 password.setcookie("password", password, 30);
 